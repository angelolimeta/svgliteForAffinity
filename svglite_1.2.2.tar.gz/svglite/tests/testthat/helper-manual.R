
init_manual_tests()
